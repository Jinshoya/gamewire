---
title: nintendo
date: 2025-04-12 13:01
end: 2025-04-12 13:01
image: /images/uploads/ninteno_direct-2x.png
borderColor: "#ff6600"
type: event
youtube:
  icon: /images/links/youtube_link.png
twitch:
  icon: /images/links/twitch_link.png
website:
  icon: /images/links/web_link.png
steam:
  icon: /images/links/steam_link.png
---
