---
title: Summer sale
date: 2025-05-02T18:15:37.947Z
end: 2025-05-22T19:00:20.601Z
image: /images/uploads/steam-2x.png
link: https://store.steampowered.com/
borderColor: "#ff0055"
type: steam_sale
---
