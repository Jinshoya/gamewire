---
title: nintendo
date: 2025-04-25T19:50:36.317Z
end: 2025-04-11T19:50:36.322Z
image: /images/uploads/ninteno_direct-2x.png
borderColor: "#ff6600"
type: event
youtube:
  icon: /images/links/youtube_link.png
twitch:
  icon: /images/links/twitch_link.png
website:
  icon: /images/links/web_link.png
steam:
  icon: /images/links/steam_link.png
---
