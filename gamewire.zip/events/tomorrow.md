---
title: Capcom
date: 2025-04-11T18:41:22.721Z
image: /images/uploads/capcom.png
link: https://gamecube.com
status: upcoming
type: event
---
